### Hexlet tests and linter status:
[![Actions Status](https://github.com/TheStarWhale/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/TheStarWhale/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/1f0630bc46b5ddcc844e/maintainability)](https://codeclimate.com/github/TheStarWhale/python-project-49/maintainability)